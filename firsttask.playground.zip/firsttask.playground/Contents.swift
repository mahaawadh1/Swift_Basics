import UIKit

var name: String = "maha"
var age: Int = 26
var GPA: Double = 3.4


print("My name is \(name)")
print("I am \(age) years old")
print("My GPA is \(GPA)")

let numericString: String = "10"

if let intValue = Int(numericString) {
    print("As an Int: \(intValue)")
} else {
    print("Unable to convert to Int")
}

if let doubleValue = Double(numericString) {
    print("As a Double: \(doubleValue)")
} else {
    print("Unable to convert to Double")
}

let ageAsDouble: Double = Double(age)
let GPAAsInt: Int = Int(GPA)

print("Age as a Double: \(ageAsDouble)")
print("GPA as an Int: \(GPAAsInt)")

var isStudent: Bool = true
print("Is a student: \(isStudent)")

if age >= 13 && age <= 19 {
    print("I am a teenager")
} else {
    print("I am not a teenager")
}

if age < 18 || age >= 65 {
    print("Eligible for discount")
} else {
    print("Not eligible for discount")
}

func isShorterOrEqualThanFive(_ text: String) -> Bool {
    return text.count <= 5
}
let text1 = "maha"
let text2 = "awadhh"
let text3 = "computer"
print(isShorterOrEqualThanFive(text1))
print(isShorterOrEqualThanFive(text2))
print(isShorterOrEqualThanFive(text3))

func convertToCelsius(_ fahrenheit: Double) -> Double {
    return (fahrenheit - 32) * 5/9
}
let fahrenheit = 98.6
let celsius = convertToCelsius(fahrenheit)
print(celsius)
